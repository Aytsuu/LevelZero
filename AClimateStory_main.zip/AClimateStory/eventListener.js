let canPress = false

window.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        drawMap(); 
        drawMapDialogue();
        animationDogRun();

        setTimeout(()=>{
            switchAnimation('idle')
        }, 1000)

        setTimeout(()=>{
            switchAnimation('run')
        }, 2000)

        setTimeout(()=>{
            switchAnimation('idle')
            canPress = true
        }, 4800)

    }, 0);
});

window.addEventListener('keyup', (event) => {
    if(!canPress) return;
    if (event.key == 'd') {
        switch(map) {
            case 1: 
                switchAnimation('run');
                setTimeout(() => {
                    startAnimation();
                    setTimeout(() => {
                        cancelAnimation()
                        changeMap(); 
                    }, 3000);
                }, 2000);
                break;
            case 2: 
                changeMap()
                animationDogRun()
                canPress = false

                setTimeout(()=>{
                    switchAnimation('idle')
                }, 1000)

                setTimeout(()=>{
                    switchAnimation('tired')
                }, 2000)

                setTimeout(()=>{
                    switchAnimation('run')
                }, 3000)

                setTimeout(()=>{
                    switchAnimation('tired')
                }, 5000)
                
                setTimeout(()=>{
                    switchAnimation('idle')
                }, 6000)

                setTimeout(()=>{
                    changeMap()
                }, 10000)

                setTimeout(()=>{
                    canPress = true
                }, 15000)

                break;
            case 4:
                changeMap()
                
                break;
            case 5:
                changeMap()
                break;
            case 6:
                changeMap()
                break;
            case 7:
                changeMap()
                break;
            case 8:
                changeMap()
                break;
            case 9:
                changeMap()
                break;
            case 10:
                changeMap()
                break;
            case 11:
                changeMap()
                break;
            case 12:
                changeMap()
                break;
            case 13:
                changeMap()
                break;
            case 14:
                changeMap()
                break;
        }
    }
});
