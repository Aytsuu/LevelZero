class Dialogue{
  constructor({gradient_fill, grad_position, grad_size, grad_content}){ 
      

      this.gradient_fill = gradient_fill;

      this.grad_position = {
          x: grad_position.grad_x,
          y: grad_position.grad_y
      }

      this.grad_size = {
          length: grad_size.grad_length,
          width: grad_size.grad_width
      }

      this.grad_content = grad_content

  }

  // Displaying the image 
  write(){
      c.fillStyle = this.gradient_fill
      c.fillRect(this.grad_position.x, this.grad_position.y, this.grad_size.width, this.grad_size.length);
      hangyabolyfont.load().then(function(loadedfont){
          document.fonts.add(loadedfont);
          // Call animateText only after the font is loaded
          animateText(dialogue);
      });
      
  }


}
const hangyabolyfont = new FontFace('Hangyaboly', 'url(./hangyaboly/Hangyaboly.ttf)');

let textAnimationStopped = false;

function animateText(grad_content) { 
  let charIndex = 0;
  let lineIndex = 0;
  let textAnimationFrame;

  function animate() {
    if (textAnimationStopped) {
      cancelAnimationFrame(textAnimationFrame);
      return;
    }

    textAnimationFrame = window.requestAnimationFrame(animate);

    c.font = '25px Hangyaboly';
    c.fillStyle = 'white';

    const text = grad_content[lineIndex]?.substring(0, charIndex) || '';
    c.fillText(text, canvas.width / 9, 100 + lineIndex * 30);

    charIndex++;

    if (text != '' && charIndex > grad_content[lineIndex].length) {
      charIndex = 0;
      lineIndex++;

      if (lineIndex > grad_content.length) {
        cancelAnimationFrame(textAnimationFrame);
      }
    }
  }

  animate();
}