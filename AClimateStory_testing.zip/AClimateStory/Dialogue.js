class Dialogue{
    constructor({gradient_fill, grad_position, grad_size, content}){

        // Declaration and Initialization

        this.img.onload = () =>{
            this.loaded = true
            
        }

        this.gradient_fill = gradient_fill

        this.grad_position = {
            x: grad_position.x,
            y: grad_position.y
        }

        this.grad_size = {
            length: grad_size.length,
            width: grad_size.width
        }

        this.content =  content; 
    }

    // Displaying the image 
    write(){
        c.fillStyle = this.gradient_fill;
        c.fillRect(this.grad_position.x, this.grad_position.y, this.grad_size.width, this.grad_size.length);
    }

    // Moving frames to create an illusion of motion
    // updateFrame(){
    //     this.elapsedFrame++
    //     if(this.elapsedFrame % this.frameBuffer === 0){
    //         if(this.currentFrame < this.frameRate - 1) this.currentFrame++
    //         else this.currentFrame = 0
    //     }
    // }
}
