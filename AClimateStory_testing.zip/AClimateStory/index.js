// // Variable Declaration and Initialization
// const canvas = document.querySelector('canvas')
// const c = canvas.getContext('2d')

// canvas.width = 1600
// canvas.height = 900


// const dogSpeed = 5;
// let dogAnimationFrame;
// let elementsAnimationFrame;
// let isRunning = true;



// // Objects
// const map1 = new Sprite({
//     position:{
//         x: 0,
//         y: 0
//     },
//     imgSrc: './Scene-bg/Scene-1.png'
// })
// const dogRun = new Elements({imgSrc: './dogImg/dog_run.png', frameRate: 9})
// const dogIdle = new Elements({imgSrc: './dogImg/dog_idle.png', frameRate: 7})


// function animationDogRun(){
//     dogAnimationFrame = window.requestAnimationFrame(animationDogRun)
//     dogRun.draw()
//     dogRun.move(dogSpeed);
// }

// function animationDogIdle(){
//     dogAnimationFrame = window.requestAnimationFrame(animationDogIdle)
//     dogIdle.position.x = dogRun.position.x
//     dogIdle.draw()
// }


// function switchAnimation(){
//     cancelAnimationFrame(dogAnimationFrame)
    

//     if(isRunning == true) {
//         isRunning = false;
//         animationDogIdle();
//     }else{
//         isRunning = true;
//         animationDogRun();
//     }
// }

const canvas = document.querySelector('canvas')
const c = canvas.getContext('2d')

canvas.width = 1600
canvas.height = 900


const dogSpeed = 5
let dogAnimationFrame
let elementsAnimationFrame
let isRunning = true
let map = 1


var gradient = c.createLinearGradient(0, 0, 0, 400);
gradient.addColorStop(0, 'rgba(0, 0, 0, 1');
gradient.addColorStop(1, 'rgba(255, 255, 255, 0.1)');
//dialogue 
var dialoguescene1 =[
    "Once upon a sunny day, a stray black dog is seen running down the streets. The rays of the sun seem brighter today of all ",
    "days, prompting people to stay indoors."
];

//font
const hangyabolyfont = new FontFace('Hangyaboly', 'url(./hangyaboly/Hangyaboly.ttf)');

hangyabolyfont.load().then(function(loadedfont){
    document.fonts.add(loadedfont)
});

// c.font = '25px Hangyaboly';
// c.fillStyle = 'white';

function animateText(dialogue) { //animation
    let charIndex = 0;
    let lineIndex = 0;
    let textAnimationFrame;
  
    function animate() {
      textAnimationFrame = window.requestAnimationFrame(animate);
  
      c.font = '25px Hangyaboly';
      c.fillStyle = 'white';
  
      const text = dialogue[lineIndex].substring(0, charIndex);
      c.fillText(text, canvas.width / 9, 100 + lineIndex * 30);
  
      charIndex++;
  
      if (charIndex > dialogue[lineIndex].length) {
        charIndex = 0;
        lineIndex++;
  
        if (lineIndex > dialogue.length) {
          cancelAnimationFrame(textAnimationFrame);
        }
      }
    }
  
    animate();
  }
  
var dialogue = [];
// Objects
let maps = {
    1: {
        init: () =>{
            background = new Sprite(
                {position:{ 
                    x: 0, 
                    y: 0 
                    
                }, imgSrc: './Scene-bg/Scene-1.png', })

            dialogue_box = new Dialogue(
                {grad_position:{
                    x: 125,
                    y: 15
                },
                grad_size: {
                    length: 200,
                    width: 1350
                }, 
                gradient_fill : gradient, 
                })
                
                //text
                // dialogue = dialoguescene1;
                // animateText(dialogue);
        }



        
    },
    2: {
        init: () =>{
            background = new Sprite(
                {position:{ 
                    x: 0, 
                    y: 0 
                }, imgSrc: './Scene-bg/newspaper.png'})
        }
    }
}

const dogRun = new Elements({imgSrc: './dogImg/dog_run.png', frameRate: 9})
const dogIdle = new Elements({imgSrc: './dogImg/dog_idle.png', frameRate: 7})


// functions

function changeMap(){
    map++
    maps[map].init()
}

// Functions 
function drawMap(){
    window.requestAnimationFrame(drawMap)
    background.draw()

}

function drawMapDialgoue(){
    window.requestAnimationFrame(drawMapDialgoue)
    dialogue_box.write()
}

function animationDogRun(){
    dogAnimationFrame = window.requestAnimationFrame(animationDogRun)
    dogRun.draw()
    dogRun.move(dogSpeed);
}

function animationDogIdle(){
    dogAnimationFrame = window.requestAnimationFrame(animationDogIdle)
    dogIdle.position.x = dogRun.position.x
    dogIdle.draw()
}


function switchAnimation(){
    cancelAnimationFrame(dogAnimationFrame)
    

    if(isRunning == true) {
        isRunning = false;
        animationDogIdle();
    }else{
        isRunning = true;
        animationDogRun();
    }
}

maps[map].init() 

