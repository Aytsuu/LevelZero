window.addEventListener('DOMContentLoaded', ()=>{
    setTimeout(()=>{
        drawMap()
        animationDogRun(); // The dog runs for 1s

        setTimeout(()=>{
            switchAnimation() // After 1s the animation will switch to idle for 2s
        },1000);

        setTimeout(()=>{
            switchAnimation() // After 2s the dog will run again nonstop
        },3000);

        setTimeout(()=>{
            switchAnimation() 
        },5000);
    })
})