// Variable Declaration and Initialization
const canvas = document.querySelector('canvas')
const c = canvas.getContext('2d')

canvas.width = 1600
canvas.height = 900


const dogSpeed = 5;
let dogAnimationFrame;
let elementsAnimationFrame;
let isRunning = true;

// Objects
const map1 = new Sprite({
    position:{
        x: 0,
        y: 0
    },
    imgSrc: './Scene-bg/Scene-1.png'
})
const dogRun = new Elements({imgSrc: './dogImg/dog_run.png', frameRate: 9})
const dogIdle = new Elements({imgSrc: './dogImg/dog_idle.png', frameRate: 7})


// Functions 
function drawMap(){
    window.requestAnimationFrame(drawMap)
    map1.draw()
}

function animationDogRun(){
    dogAnimationFrame = window.requestAnimationFrame(animationDogRun)
    dogRun.draw()
    dogRun.move(dogSpeed);
}

function animationDogIdle(){
    dogAnimationFrame = window.requestAnimationFrame(animationDogIdle)
    dogIdle.position.x = dogRun.position.x
    dogIdle.draw()
}


function switchAnimation(){
    cancelAnimationFrame(dogAnimationFrame)
    

    if(isRunning == true) {
        isRunning = false;
        animationDogIdle();
    }else{
        isRunning = true;
        animationDogRun();
    }
}