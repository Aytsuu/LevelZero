// Variable Declaration and Initialization
const canvas = document.querySelector('canvas')
const c = canvas.getContext('2d')

canvas.width = 1600
canvas.height = 900


const dogSpeed = 5;
let animationFrame;
let isRunning = true;

// Objects
const map1 = new Sprite({
    position:{
        x: 0,
        y: 0
    },
    imgSrc: './Scene-bg/Scene-1.png'
})
const dogRun = new Dog({imgSrc: './dogImg/dog_run_test.png', frameRate: 9})
const dogIdle = new Dog({imgSrc: './dogImg/dog_idle_test.png', frameRate: 7})


// Functions 
function drawMap(){
    window.requestAnimationFrame(drawMap)
    map1.draw()
}

function animationDogRun(){
    animationFrame = window.requestAnimationFrame(animationDogRun)
    dogRun.draw()
    dogRun.move(dogSpeed);
}

function animationDogIdle(){
    animationFrame = window.requestAnimationFrame(animationDogIdle)
    dogIdle.position.x = dogRun.position.x
    dogIdle.draw()
}

function switchAnimation(){
    cancelAnimationFrame(animationFrame)
    

    if(isRunning == true) {
        isRunning = false;
        animationDogIdle();
    }else{
        isRunning = true;
        animationDogRun();
    }
}