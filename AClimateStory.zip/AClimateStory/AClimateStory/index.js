// Variable Declaration and Initialization
const canvas = document.querySelector('canvas')
const c = canvas.getContext('2d')

canvas.width = 1600
canvas.height = 900


const dogSpeed = 5;
let dogAnimationFrame;
let elementsAnimationFrame;
let isRunning = true;

//gradient
var gradient = c.createLinearGradient(0, 0, 0, 400);
gradient.addColorStop(0, 'rgba(0, 0, 0, 1');
gradient.addColorStop(1, 'rgba(255, 255, 255, 0.1)');

//dialgogue 
const dialoguescene1 =[
    "Once upon a sunny day, a stray black dog is seen running down the streets. The rays of the sun seem brighter today of all ",
    "days, prompting people to stay indoors.."
];

//font
const hangyabolyfont = new FontFace('Hangyaboly', 'url(./hangyaboly/Hangyaboly.ttf)');

hangyabolyfont.load().then(function(loadedfont){
    document.fonts.add(loadedfont)
});

// Objects
const map1 = new Sprite({
    position:{
        x: 0,
        y: 0
    },
    imgSrc: './Scene-bg/Scene-1.png'
})
const dogRun = new Elements({imgSrc: './dogImg/dog_run.png', frameRate: 9})
const dogIdle = new Elements({imgSrc: './dogImg/dog_idle.png', frameRate: 7})

// functions
function animateText() { //animation
    let charIndex = 0;
    let lineIndex = 0;
    let textAnimationFrame;
  
    function animate() {
      textAnimationFrame = window.requestAnimationFrame(animate);
  
      c.font = '25px Hangyaboly';
      c.fillStyle = 'white';
  
      const text = dialoguescene1[lineIndex].substring(0, charIndex);
      c.fillText(text, canvas.width / 9, 100 + lineIndex * 30);
  
      charIndex++;
  
      if (charIndex > dialoguescene1[lineIndex].length) {
        charIndex = 0;
        lineIndex++;
  
        if (lineIndex > dialoguescene1.length) {
          cancelAnimationFrame(textAnimationFrame);
        }
      }
    }
  
    animate();
  }


function drawMap(){
    window.requestAnimationFrame(drawMap)
    map1.draw()

    //narration box
    c.fillStyle = gradient;
    c.fillRect(125, 15, 1350, 200);
    //text
    c.font = '25px Hangyaboly';
    c.fillStyle = 'white';
    animateText();

}

function animationDogRun(){
    dogAnimationFrame = window.requestAnimationFrame(animationDogRun)
    dogRun.draw()
    dogRun.move(dogSpeed);
}

function animationDogIdle(){
    dogAnimationFrame = window.requestAnimationFrame(animationDogIdle)
    dogIdle.position.x = dogRun.position.x
    dogIdle.draw()
}


function switchAnimation(){
    cancelAnimationFrame(dogAnimationFrame)
    

    if(isRunning == true) {
        isRunning = false;
        animationDogIdle();
    }else{
        isRunning = true;
        animationDogRun();
    }
}

